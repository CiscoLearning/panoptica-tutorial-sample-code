#! /bin/bash

kind delete clusters demo
